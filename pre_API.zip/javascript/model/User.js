class User {
    constructor(idUser, name, lastName, email, passport, phone, day, month, year,) {
        this.idUser = idUser
        this.name = name
        this.lastName = lastName
        this.passport = passport
        this.email = email
        this.phone = phone
        this.day = day
        this.month = month
        this.year = year
    }
}